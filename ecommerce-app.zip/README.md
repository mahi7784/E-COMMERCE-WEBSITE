
# 🛒 E-Commerce App

A simple E-commerce web app built with Next.js. Users can browse products, add to cart, and simulate checkout.

## 🚀 Features
- Product catalog with images, names, and prices
- Product details page
- Add/remove products from shopping cart
- User authentication (signup/login)
- Checkout simulation
- Order history (optional)
- Responsive UI for mobile and desktop

## 🛠️ Tech Stack
- Next.js / React
- Node.js + Express (optional backend API)
- MongoDB / Firebase (optional database)
- CSS / Tailwind (styling)

## ▶️ How to Run
1. Clone repo
2. Install dependencies with `npm install`
3. Run project with `npm run dev`
