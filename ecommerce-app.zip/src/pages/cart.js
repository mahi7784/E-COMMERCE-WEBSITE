
export default function Cart() {
  return <h2>Your shopping cart is empty (mock page)</h2>;
}
