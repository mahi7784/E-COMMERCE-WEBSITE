
import ProductCard from '../components/ProductCard';

const sampleProducts = [
  { id: 1, name: 'Product 1', price: 100, image: '/product1.jpg' },
  { id: 2, name: 'Product 2', price: 150, image: '/product2.jpg' }
];

export default function Home() {
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', padding: '2rem' }}>
      {sampleProducts.map(product => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}
